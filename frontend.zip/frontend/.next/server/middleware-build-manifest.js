globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/T2S0ZeriwQXB_gLjrnF4h/_buildManifest.js",
    "static/T2S0ZeriwQXB_gLjrnF4h/_ssgManifest.js",
    "static/T2S0ZeriwQXB_gLjrnF4h/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3ivcc6t1s04dh.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/12_celfi3iros.js",
    "static/chunks/3ertolydtjaa3.js",
    "static/chunks/turbopack-0whc5cr1bqeba.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
