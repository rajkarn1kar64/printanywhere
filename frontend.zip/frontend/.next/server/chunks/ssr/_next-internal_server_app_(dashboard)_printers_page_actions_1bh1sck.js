module.exports=[44261,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_printers_page_actions_1bh1sck.js.map