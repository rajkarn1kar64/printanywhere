module.exports=[2095,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_printers_register_page_actions_0ntu0au.js.map