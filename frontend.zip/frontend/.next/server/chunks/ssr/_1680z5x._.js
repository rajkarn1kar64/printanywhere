module.exports=[44536,(a,b,c)=>{let{createClientModuleProxy:d}=a.r(11857);a.n(d("[project]/node_modules/next/dist/client/script.js"))},11153,a=>{"use strict";var b=a.i(44536);a.n(b)},71618,(a,b,c)=>{b.exports=a.r(11153)},29735,a=>{"use strict";var b=a.i(7997),c=a.i(71618);a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"en",suppressHydrationWarning:!0,children:[(0,b.jsx)("head",{children:(0,b.jsx)(c.default,{id:"theme-script",strategy:"beforeInteractive",children:`
            (function () {
              try {
                const theme =
                  localStorage.getItem("theme");

                if (theme === "light") {
                  document.documentElement.classList.remove(
                    "dark"
                  );
                } else {
                  document.documentElement.classList.add(
                    "dark"
                  );
                }
              } catch (error) {
                document.documentElement.classList.add(
                  "dark"
                );
              }
            })();
          `})}),(0,b.jsx)("body",{className:"\n          bg-slate-100\n          text-slate-900\n          transition-colors\n          duration-300\n          dark:bg-slate-950\n          dark:text-white\n        ",children:a})]})},"metadata",0,{title:"PrintAnywhere",description:"Remote printing platform"}])},81967,function(a){a.n(a.i(29735))}];

//# sourceMappingURL=_1680z5x._.js.map